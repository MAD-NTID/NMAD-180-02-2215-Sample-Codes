﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MAD4UFOS;

namespace AlienTests
{
    [TestClass]

    public class AlienSearchTests
    {
        [TestMethod]
        public void BlankAlienIsNotFound()
        {
            string search = "";

            Assert.IsFalse(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void NullAlienIsNotFound()
        {
            string search = null;

            Assert.IsFalse(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CockroachIsFound()
        {
            string search = "Cockroach";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CricketIsFound()
        {
            string search = "Cricket";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void OctoIsFound()
        {
            string search = "Octo";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CockroachIsNotFound()
        {
            string search = "CockroachBad";

            Assert.IsFalse(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CricketIsNotFound()
        {
            string search = "CricketBad";

            Assert.IsFalse(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void OctoIsNotFound()
        {
            string search = "OctoBad";

            Assert.IsFalse(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CockroachAllLowerIsFound()
        {
            string search = "cockroach";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void CricketAllLowerIsFound()
        {
            string search = "cricket";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }

        [TestMethod]
        public void OctoIsAllLowerFound()
        {
            string search = "octo";

            Assert.IsTrue(Alien.HaveSpecies(search));
        }
    }
}
