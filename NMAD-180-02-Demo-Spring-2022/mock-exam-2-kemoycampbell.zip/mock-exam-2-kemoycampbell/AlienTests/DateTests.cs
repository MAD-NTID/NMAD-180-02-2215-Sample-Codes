using Microsoft.VisualStudio.TestTools.UnitTesting;
using MAD4UFOS;

namespace AlienTests
{
    [TestClass]
    public class DateTests
    {
        [TestMethod]
        public void DateStringMMddyyyyIsGood()
        {
            string date = "01/01/1999";

            Assert.IsTrue(Alien.DateIsValid(date));
        }

        [TestMethod]
        public void DateStringMdyyyyIsGood()
        {
            string date = "1/1/1999";

            Assert.IsTrue(Alien.DateIsValid(date));
        }

        [TestMethod]
        public void DateStringIsBad()
        {
            string date = "01011999";

            Assert.IsFalse(Alien.DateIsValid(date));
        }
    }
}
